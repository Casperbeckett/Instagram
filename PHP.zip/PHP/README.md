# Fake-Instagram-Follower-Phishing-
It is simple layout which looks like a free instagram follower increasing site but actually its a phishing page which captures the login info of users.

# Demo
https://xploitwizer.me/InstaFollowers  (Not Available)

How to use :
> just host it on a hosting and change permission of login.txt to 777


# Happy Hacking 

### XploitWizer Provides no warranty with this software and will not be responsible for any direct or indirect damage caused due to the usage of this tool.
### Instagram-Follower-Phishing is built for Educational Purpose. Use at your own Risk.

# Team XploitWizer 
